# Calendário de 14 dias — Central Leonida

Um post por dia, no máximo. Sinalize “link de afiliado”. Não prometa renda. Os arquivos estão nas pastas `imagens/` e `videos/` deste kit.

---

## Semana 1 — problema e descoberta

### Dia 1 — Reel 01

**Asset:** `videos/reel-01-o-que-falta-v5.mp4`
**Gancho:** “Você sabe o que falta para o 100%?”
**Legenda:** A planilha mostra o progresso por categoria. Você marca o que já fez e vê o que falta. Link na bio. #GTA6 #GTA6Brasil #Platina
**CTA:** Link na bio.

### Dia 2 — Post com o criativo da planilha

**Asset:** `imagens/plain-ad-01-planilha-1080x1080.jpg`
**Gancho:** “Planilha para o 100% de GTA 6.”
**Legenda:** Requisitos, missões, troféus e contadores em um arquivo. O painel mostra o que falta. Link de afiliado na bio.

### Dia 3 — Story com enquete

**Asset:** `imagens/plain-ad-03-painel-1080x1920.jpg`
**Texto:** “Quanto você já fez do 100%?”
**Enquete:** “Menos de 50%” / “Mais de 50%” / “Já platinei”.
**CTA:** “Quer saber o que falta? Link na bio.”

### Dia 4 — Reel 02

**Asset:** `videos/reel-02-tres-erros-v5.mp4`
**Gancho:** “Três coisas que travam o seu 100%.”
**Legenda:** Perdível deixado para depois, colecionável sem controle e falta de progresso. A planilha organiza os três. Link de afiliado.

### Dia 5 — Post com o criativo do requisito

**Asset:** `imagens/plain-ad-02-requisito-1080x1080.jpg`
**Gancho:** “Cada requisito tem uma meta e uma caixa.”
**Legenda:** Você marca o que concluiu. O painel calcula o resto. Google Sheets ou Excel. Link na bio.

### Dia 6 — Story de bastidor

**Asset:** `imagens/plain-social-04-conteudo.jpg`
**Texto:** “É assim que eu acompanho o progresso.”
**CTA:** “Pergunta? Responde aqui.”

### Dia 7 — Reel 03

**Asset:** `videos/reel-03-quanto-falta-v5.mp4`
**Gancho:** “Quanto falta para platinar?”
**Legenda:** O painel mostra o percentual por categoria. Você abre e vê o que falta. Link de afiliado.

---

## Semana 2 — prova e conversão

### Dia 8 — Post com o criativo das abas

**Asset:** `imagens/plain-ad-04-conteudo-1080x1080.jpg`
**Gancho:** “Pare de abrir dez abas.”
**Legenda:** Requisitos, missões e troféus em um arquivo. Link na bio.

### Dia 9 — Reel 04

**Asset:** `videos/reel-04-tudo-em-um-v5.mp4`
**Gancho:** “Tudo em um só lugar.”
**Legenda:** A planilha reúne requisitos, missões, troféus e contadores. Guia não oficial. Link de afiliado.

### Dia 10 — Story com o checklist grátis

**Asset:** `imagens/plain-ad-05-checklist-1080x1920.jpg`
**Texto:** “Teste de graça: checklist do 100%.”
**CTA:** Link do checklist gratuito + link de afiliado.

### Dia 11 — Post com o checklist grátis

**Asset:** `imagens/plain-ad-05-checklist-1080x1080.jpg`
**Gancho:** “Checklist do 100% em PDF, grátis.”
**Legenda:** Baixe, imprima e marque. A versão completa tem o painel de progresso. Link na bio.

### Dia 12 — Reel 05

**Asset:** `videos/reel-05-checklist-gratis-v5.mp4`
**Gancho:** “Checklist grátis.”
**Legenda:** Comece sem pagar nada. O checklist do 100% está em uma página. Link na bio.

### Dia 13 — Story com o seu progresso

**Asset:** `imagens/plain-social-03-painel.jpg`
**Texto:** “Meu progresso hoje: X%.”
**Legenda:** Mostre o painel com o seu progresso. Se usar dados de exemplo, diga que são exemplo. Convide a audiência a comentar o dela.

### Dia 14 — Reel 01 de novo, com CTA

**Asset:** `videos/reel-01-o-que-falta-v5.mp4`
**Gancho:** “Ainda não sabe o que falta?”
**Legenda:** Fecha a série com o link de afiliado e o checklist gratuito.

---

## Regras rápidas

- Use no máximo 3 hashtags por post. Exemplo: `#GTA6 #GTA6Brasil #Platina`.
- Adapte o texto ao tamanho de cada plataforma. Não copie igual em todas.
- Não use artes ou vídeos oficiais da Rockstar.
- Não prometa “100% garantido” nem renda.
- Não abra o post com uma lista de números.
- Se um post funcionar bem, repita o formato com outro gancho, não o mesmo texto.
- Guarde os links e os resultados para pedir variações de criativo.
