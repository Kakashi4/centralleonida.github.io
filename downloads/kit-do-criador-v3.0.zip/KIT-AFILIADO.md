# Guia do Afiliado — Central Leonida

Ganchos, roteiros e textos para divulgar a planilha. Use o que fizer sentido para o seu canal.

## 1. Antes de começar

- **Conheça o produto.** A planilha organiza requisitos, missões, troféus e contadores, com painel de progresso. O Main inclui também dois guias e um tour em vídeo.
- **Teste sem pagar.** Use o cupom `PARCEIRO100`.
- **Pegue seu link.** Cadastre-se em https://centralleonida.gumroad.com/affiliates.
- **Sinalize a divulgação.** Diga que o link é de afiliado na descrição, na legenda ou na bio.

## 2. Ganchos

- “Você sabe o que falta para o 100% de GTA 6?”
- “Quanto falta para você platinar?”
- “Três coisas que fazem você perder tempo no 100%.”
- “A planilha mostra o que falta por categoria.”
- “Chega de abrir dez abas para achar uma missão.”

## 3. Roteiros de vídeo (15 a 30 segundos)

### Roteiro 1 — O problema

**Gancho (0–3s):** “Se você está jogando GTA 6 e quer platinar, presta atenção.”

**Corpo (3–15s):** “Eu montei uma planilha que organiza requisitos, missões e troféus. Você marca o que já fez e o painel mostra o que falta. Tem guia sem spoilers e versão para imprimir.”

**CTA (15–20s):** “Link na bio. Tem checklist grátis.”

### Roteiro 2 — Três erros

**Gancho (0–3s):** “Três coisas que travam o seu 100% no GTA 6.”

**Corpo (3–18s):** “Uma: deixar missão perdível para depois. Duas: caçar colecionável sem controle. Três: não saber quanto falta. A planilha organiza o progresso e mostra o que é perdível.”

**CTA (18–22s):** “Link na bio.”

### Roteiro 3 — Progresso

**Gancho (0–3s):** “Quanto falta para você platinar o GTA 6?”

**Corpo (3–15s):** “A planilha mostra o progresso por categoria: história, exploração, descobertas, missões e troféus. Você abre e vê o que falta.”

**CTA (15–20s):** “Link na bio. Acesso imediato.”

## 4. Posts

### Post 0 — Convite para criadores

> Criadores de conteúdo de GTA 6: o programa de afiliados da Central Leonida está aberto.
>
> São 30% por venda, e 40% para os cinco primeiros aprovados.
>
> O kit tem roteiros, posts, criativos e vídeos prontos. Cadastro: https://centralleonida.gumroad.com/affiliates
>
> Guia não oficial.

### Post 1 — Feed

> Se você está jogando GTA 6 e quer platinar, salva esse post.
>
> A Central Leonida é uma planilha que organiza o seu progresso. Você marca o que já fez e o painel mostra o que falta.
>
> Requisitos, missões e troféus em um arquivo. Guias sem spoilers. Versão para imprimir.
>
> Link na bio. #GTA6 #GTA6Brasil #Platina

### Post 2 — Story ou legenda de Reels

> O 100% do GTA 6 é longo.
>
> A planilha marca o que você já fez e mostra o que falta. Sem aba perdida e sem spoiler.
>
> Link na bio.

### Post 3 — Transparência

> A planilha é oficial?
>
> Não. É um guia não oficial, sem vínculo com a Rockstar ou a Take-Two. Não usa artes, imagens ou trechos do jogo.
>
> O que ela faz: organiza requisitos, missões, troféus e contadores em português, com painel de progresso.
>
> Guia não oficial, para jogadores.

## 5. Mensagem para comunidade ou WhatsApp

> Oi! Se você joga GTA 6 e quer platinar, essa planilha pode economizar um bom tempo: [SEU LINK]
>
> Ela organiza o progresso e mostra o que falta. Tem guia dos primeiros 10 horas sem spoilers.
>
> Qualquer dúvida, me chama.

Use só em contatos que pediram ou em comunidades onde divulgação é permitida. Não use listas compradas, grupos sem permissão nem mensagem em massa.

## 6. Medidas dos criativos

- **Feed:** 1080×1080.
- **Stories e Reels:** 1080×1920.
- **Prévia de link:** 1200×628.
- **YouTube:** thumbnail 1280×720.
- **Vídeo:** 15 a 30 segundos, gravação de tela da planilha, legendas em PT-BR, sem gameplay.
- **Texto na tela:** uma frase curta, legível. Sem contadores ou listas de números.
- **Divulgação:** “Link de afiliado” na legenda ou na bio.

## 7. Regras

- Divulgue o link de afiliado de forma clara.
- Não prometa renda, resultado ou “100% garantido em X horas”.
- Não use logos, capturas ou artes oficiais da Rockstar ou da Take-Two.
- Não faça spam. Siga as regras de cada comunidade.
- Não prometa mapa interativo, localização de colecionáveis ou lista nominal de missões secundárias.
- Siga os termos de afiliados da Gumroad e o CDC: oferta clara, garantia de 7 dias e canal de suporte.

## 8. O que o afiliado pode dizer (e o que não pode)

**Pode:**

- “Planilha em português para acompanhar o 100% de GTA 6.”
- “O painel mostra o que falta por categoria.”
- “Guias sem spoilers.”
- “Tour em vídeo de 6 minutos, sem narração.”
- “Atualizações grátis por 12 meses.”
- “Guia não oficial.”

**Não pode:**

- Abrir o post com uma lista de números.
- “Lista completa de todas as missões secundárias.”
- “Mapa com todas as localizações.”
- “Método infalível para ganhar dinheiro com GTA 6.”
- “Produto oficial da Rockstar.”
- “100% garantido em X horas.”
