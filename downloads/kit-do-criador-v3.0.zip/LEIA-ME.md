# Kit do Criador — Central Leonida

**Versão 3.0.** Este kit tem os criativos, os vídeos, os roteiros e o guia de marca para você divulgar a Central Leonida.

## 1. Cadastro

1. Acesse **https://centralleonida.gumroad.com/affiliates**.
2. Crie sua conta de afiliado na Gumroad. Leva cerca de dois minutos.
3. Você recebe um **link próprio** e um painel de vendas.
4. A comissão é de **30% por venda**. Os **cinco primeiros criadores aprovados** recebem **40%**.

## 2. Cupons

| Cupom | Para quê | Uso |
|---|---|---|
| `PARCEIRO100` | Testar o produto sem custo | 100% off, 50 usos, para criadores |
| `LEONIDA20` | Oferecer à sua audiência | 20% off, 100 usos |

Você pode usar o `LEONIDA20` junto com o seu link de afiliado.

**Demo pública (30s):** https://kakashi4.github.io/centralleonida.github.io/downloads/demo-30s.mp4
É uma boa forma de apresentar o produto sem pedir compra.

## 3. O que está no kit

| Pasta / arquivo | Conteúdo |
|---|---|
| `Parceria-Central-Leonida-Afiliados.pdf` | One-pager com comissão, produto e regras |
| `videos/` | Reels + demo de 30s (16:9 e vertical), sem narração |
| `imagens/` | Criativos em três formatos, thumbnails de YouTube e posts 1080×1080 |
| `marca/` | Logos horizontal (fundo claro/escuro), ícone quadrado e guia de marca |
| `KIT-AFILIADO.md` | Ganchos, roteiros, legendas e regras de uso |
| `CALENDARIO-14-DIAS.md` | Plano de 14 dias com assets, ganchos e legendas |

## 4. Como usar os criativos

- **Feed:** use as imagens 1080×1080.
- **Stories e Reels:** use as 1080×1920 ou os vídeos verticais.
- **Prévia de link:** use as 1200×628.
- **Texto na tela:** já está em português; não precisa editar.
- **Vídeos:** são mudos. Se quiser, adicione uma música licenciada na plataforma.
- **Logo:** não altere cores, proporções ou o texto.

## 5. O que falar (e o que não falar)

**Pode:**

- “Planilha em português para acompanhar o 100% de GTA 6.”
- “O painel mostra o que falta por categoria.”
- “Guias sem spoilers.”
- “Tour em vídeo de 6 minutos, sem narração.”
- “Atualizações grátis por 12 meses.”
- “Guia não oficial.”

**Não pode:**

- “Lista completa de todas as missões secundárias.”
- “Mapa com todas as localizações.”
- “Método infalível para ganhar dinheiro.”
- “Produto oficial da Rockstar.”
- “100% garantido em X horas.”

## 6. Transparência

Sempre sinalize que o link é de afiliado, na descrição do vídeo, na legenda ou na bio. A Gumroad rastreia a venda pelo seu link. Você não precisa pedir o e-mail de ninguém.

## 7. Suporte

Dúvidas sobre o produto ou o programa: responda ao e-mail da sua aprovação de afiliado ou use o canal de suporte da Gumroad.

Central Leonida
