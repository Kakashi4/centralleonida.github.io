# Guia de Marca — Central Leonida

Regras rápidas para usar o nome, o logo e as cores nos seus posts.

## 1. Nome

- Use **Central Leonida**, duas palavras, sem acento.
- Produto: **Central Leonida — Planilha 100% para GTA 6 (Guia Não Oficial)**.
- Não use “Central Léonida”, “CentralLeonida” ou “Central Leonida BR”.
- Na primeira menção de um post, use “Central Leonida, a planilha do 100% de GTA 6”.

## 2. Cores

| Uso | Hex |
|---|---|
| Fundo | `#FFFFFF` |
| Texto | `#111111` |
| Texto secundário | `#555555` |
| Linhas | `#D9D9D9` |
| Links | `#174A8B` |

Use branco, preto e cinza. O roxo e o lavanda que aparecem nas capturas são do arquivo Excel,
não da marca. Não recrie esses blocos como decoração.

Sem gradiente, sombra, cartão arredondado, chip, pílula ou gráfico de números. Se precisar de
contraste, use texto preto sobre branco.

## 3. Tipografia

- Materiais e PDFs: **Lato**.
- Site: fonte do sistema (Helvetica/Arial ou a sans-serif padrão do aparelho).
- Não use Bebas Neue, Barlow Condensed, Impact ou imitação de fonte da Rockstar.
- Títulos com peso normal ou semibold. Não use letras gigantes como decoração.

## 4. Logos

Arquivos na pasta `marca/`:

| Arquivo | Uso |
|---|---|
| `logo-horizontal-dark.png` | Fundos escuros (texto claro) |
| `logo-horizontal-light.png` | Fundos claros (texto escuro) |
| `logo-square.png` | Avatar ou ícone (fundo branco) |

Não altere cores, proporções ou o texto. Mantenha respiro ao redor. Não coloque o logo sobre
arte do jogo.

## 5. O que pode e o que não pode

**Pode:**

- “Planilha em português para acompanhar o 100% de GTA 6.”
- “O painel mostra o que falta por categoria.”
- “Funciona no Excel e no Google Sheets.”
- “Guias sem spoilers.”
- “Tour em vídeo, sem narração.”
- “Atualizações grátis por 12 meses.”
- “Guia não oficial.”

**Não pode:**

- Abrir o post com uma lista de números ou uma contagem de itens.
- “Lista completa de todas as missões secundárias.”
- “Mapa com todas as localizações.”
- “Método infalível para ganhar dinheiro.”
- “Produto oficial da Rockstar.”
- “100% garantido em X horas.”

Use uma frase concreta e uma captura real do arquivo. Não monte painéis, cards ou infográficos
com estatísticas.

## 6. Divulgação de afiliado

Sempre sinalize na descrição, legenda ou bio que o link é de afiliado.
